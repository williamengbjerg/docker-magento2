| Q                    | A
| -------------------- | -----
| Bug report?          | yes/no
| Feature request?     | yes/no
| BC Break report?     | yes/no
| RFC? / Specification | yes/no
| Library version      | x.y(.z)

<!--
Fill in this template according to your issue.
Otherwise, replace this comment by the description of your issue.

Please consider the following requirements
* You MUST never send security issues here. If you think that your issue is a security one then contact Spomky in private at https://gitter.im/Spomky/
* You should not post many lines of source code or console logs. Small inputs (approx 5 lines) are acceptable otherwize you should use a third party service (e.g. Pastebin, Chop...).
-->
