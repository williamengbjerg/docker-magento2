<?php
namespace CBOR;

class CBORIncorrectAdditionalInfoException extends \Exception{}

