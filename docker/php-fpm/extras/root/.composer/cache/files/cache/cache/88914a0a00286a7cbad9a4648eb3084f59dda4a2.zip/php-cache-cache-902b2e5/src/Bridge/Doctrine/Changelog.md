# Change Log

The change log describes what is "Added", "Removed", "Changed" or "Fixed" between each release.

## 3.0.0

### Changed

* Changed Namespace from `Cache\Bridge` to `Cache\Bridge\Doctrine`

## 2.2.0

No changelog before this version
