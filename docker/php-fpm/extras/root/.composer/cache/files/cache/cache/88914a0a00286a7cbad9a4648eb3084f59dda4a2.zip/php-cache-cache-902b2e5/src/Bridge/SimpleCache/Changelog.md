# Change Log

The change log describes what is "Added", "Removed", "Changed" or "Fixed" between each release. 

## UNRELEASED
## 0.1.1

### Fixed

* Bugs with iterators

## 0.1.0

First release
