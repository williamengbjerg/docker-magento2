| Question      | Answer
| ------------- | ------
| Bug fix?      | yes/no
| New feature?  | yes/no
| BC breaks?    | yes/no
| Deprecations? | yes/no
| Tests pass?   | yes/no
| Fixed tickets | comma-separated list of tickets fixed by the PR, if any
| License       | MIT
| Doc PR        | reference to the documentation PR, if any

### Description



### TODO
* [ ] Add tests
* [ ] Add documentation
* [ ] Updated Changelog.md
