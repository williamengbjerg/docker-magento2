# Change Log

The change log describes what is "Added", "Removed", "Changed" or "Fixed" between each release. 

## UNRELEASED
## 0.2.1

### Fixed

Typos, documentation and general package improvements.

## 0.2.0

No changelog before this version
