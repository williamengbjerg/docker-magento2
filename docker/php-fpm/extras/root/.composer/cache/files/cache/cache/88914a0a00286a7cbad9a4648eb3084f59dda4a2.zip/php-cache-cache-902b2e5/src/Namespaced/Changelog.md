# Change Log

The change log describes what is "Added", "Removed", "Changed" or "Fixed" between each release. 

## UNRELEASED

## 0.1.2

### Fixed

Typos, documentation and general package improvements.

## 0.1.1

### Changed

* Updated type hints for the cache pool.
* Using `cache/hierarchical-cache:^0.3`

## 0.1.0

First release
