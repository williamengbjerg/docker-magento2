<?php

namespace JMS\Serializer\Tests\Fixtures;

class InlineChildEmpty
{

}
