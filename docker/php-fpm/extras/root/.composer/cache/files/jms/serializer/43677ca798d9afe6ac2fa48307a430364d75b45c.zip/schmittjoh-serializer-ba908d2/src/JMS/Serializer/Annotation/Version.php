<?php

namespace JMS\Serializer\Annotation;

abstract class Version
{
    /**
     * @Required
     * @var string
     */
    public $version;
}
