<?php

namespace JMS\Serializer\Exception;

class UnsupportedFormatException extends InvalidArgumentException
{
}
