<?php

namespace JMS\Serializer\Exception;

/**
 * Base exception for the Serializer.
 *
 * @author Johannes M. Schmitt <schmittjoh@gmail.com>
 */
interface Exception
{
}
