<?php

namespace JMS\Serializer\Tests\Fixtures\Discriminator;

class ObjectWithXmlNamespaceDiscriminatorChild extends ObjectWithXmlNamespaceDiscriminatorParent
{
}
