<?php

namespace Metadata\Tests\Driver\Fixture\C\SubDir;

class C { }