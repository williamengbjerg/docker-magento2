<?php

namespace Metadata\Tests\Driver\Fixture\A;

class A {}
