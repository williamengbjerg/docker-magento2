<?php

class D { }
