<?php

namespace Metadata;

final class Version
{
    const VERSION = '1.6-DEV';
}
