<?php

// This is global bootstrap for autoloading

// VCR cassette path
\VCR\VCR::configure()->setCassettePath(__DIR__ . '/_data/vcr');
