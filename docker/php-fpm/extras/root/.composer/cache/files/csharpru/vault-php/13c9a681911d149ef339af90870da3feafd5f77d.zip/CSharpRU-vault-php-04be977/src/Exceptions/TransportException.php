<?php

namespace Vault\Exceptions;

/**
 * Class TransportException
 *
 * @package Vault\Exceptions
 */
class TransportException extends \RuntimeException
{
}