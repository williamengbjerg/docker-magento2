<?php

namespace Vault\Exceptions;

/**
 * Class ServerException
 *
 * @package Vault\Exception
 */
class ServerException extends AbstractResponseException
{
}
