<?php

namespace Vault\Exceptions;

/**
 * Class ClientException
 *
 * @package Violuke\Vault\Exception
 */
class ClientException extends AbstractResponseException
{
}
