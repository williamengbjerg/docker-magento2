# Inventory Shipping Admin Ui Functional Tests

The Functional Test Module for **Magento Inventory Shipping Admin Ui** module.
