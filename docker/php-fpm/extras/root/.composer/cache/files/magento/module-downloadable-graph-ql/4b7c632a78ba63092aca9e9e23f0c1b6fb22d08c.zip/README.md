# DownloadableGraphQl

**DownloadableGraphQl** provides type and resolver information for the GraphQl module
to generate downloadable product information.
