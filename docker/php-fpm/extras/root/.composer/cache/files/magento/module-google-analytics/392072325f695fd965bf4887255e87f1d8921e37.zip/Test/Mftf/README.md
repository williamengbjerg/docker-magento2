# Google Analytics Functional Tests

The Functional Test Module for **Magento Google Analytics** module.
