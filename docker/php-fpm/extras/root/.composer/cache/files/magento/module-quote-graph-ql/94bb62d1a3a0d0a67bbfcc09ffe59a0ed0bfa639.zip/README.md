# QuoteGraphQl

**QuoteGraphQl** provides type and resolver information for the GraphQl module
to generate quote (cart) information endpoints. Also provides endpoints for modifying a quote.
