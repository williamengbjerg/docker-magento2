Magento_GoogleAnalytics is a module for integration with Google Analytics service.
