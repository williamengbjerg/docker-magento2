# Configurable Import Export Functional Tests

The Functional Test Module for **Magento Configurable Import Export** module.
