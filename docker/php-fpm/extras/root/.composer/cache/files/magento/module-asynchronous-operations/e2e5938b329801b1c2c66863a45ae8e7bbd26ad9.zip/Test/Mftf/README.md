# Asynchronous Operations Functional Tests

The Functional Test Module for **Magento Asynchronous Operations** module.
