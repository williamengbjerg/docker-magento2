# Tinymce3 Functional Tests

The Functional Test Module for **Magento Tinymce3** module.
