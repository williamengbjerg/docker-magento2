# StoreGraphQl

**StoreGraphQl** provides type information for the GraphQl module
to generate store fields information endpoints.
