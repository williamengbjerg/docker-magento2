# Magento_MediaGalleryMetadataApi

The Magento_MediaGalleryMetadataApi module is responsible for the media gallery metadata implementation API.
