# Inventory Bundle Product Functional Tests

The Functional Test Module for **Magento Inventory Bundle Product** module.
