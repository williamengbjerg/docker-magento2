Magento_Csp implements Content Security Policies for Magento. Allows CSP configuration for Merchants,
provides a way for extension and theme developers to configure CSP headers for their extensions.
