# RelatedProductGraphQl

**RelatedProductGraphQl** provides endpoints for getting  Cross Sell / Related/ Up Sell products data.