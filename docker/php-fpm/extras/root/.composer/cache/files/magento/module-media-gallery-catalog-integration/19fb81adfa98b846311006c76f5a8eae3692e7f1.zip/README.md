# Magento_MediaGalleryCatalogIntegration

The purpose of this module is for extending catalog image uploader functionality.
