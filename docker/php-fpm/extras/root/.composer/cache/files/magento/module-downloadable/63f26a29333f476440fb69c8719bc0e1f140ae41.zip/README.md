Magento_Downloadable module introduces new product type in the Magento application called Downloadable Product.
This module is designed to extend existing functionality of Magento_Catalog module by adding new product type.
