# LoginAsCustomerGraphQl

**LoginAsCustomerGraphQl** provides flexible login as a customer so a merchant or merchant admin can log into an end customer's account to assist them with their account.
