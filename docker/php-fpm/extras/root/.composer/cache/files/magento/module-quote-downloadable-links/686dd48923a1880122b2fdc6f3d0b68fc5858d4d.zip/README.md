# QuoteDownloadableLinks

**QuoteDownloadableLinks** provides data provider for creating buy request for links of downloadable products.
