# MsrpGroupedProduct

**MsrpGroupedProduct** provides type and resolver information for the Msrp module from the GroupedProduct module.