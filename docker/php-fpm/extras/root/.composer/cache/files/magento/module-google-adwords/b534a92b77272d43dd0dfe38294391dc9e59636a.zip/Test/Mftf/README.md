# Google Adwords Functional Tests

The Functional Test Module for **Magento Google Adwords** module.
