# Require Js Functional Tests

The Functional Test Module for **Magento Require Js** module.
