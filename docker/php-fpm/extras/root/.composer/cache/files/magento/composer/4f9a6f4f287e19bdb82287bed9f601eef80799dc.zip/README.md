Magento composer library helps to instantiate Composer application and run composer commands.
