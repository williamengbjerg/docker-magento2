# Newsletter Functional Tests

The Functional Test Module for **Magento Newsletter** module.
