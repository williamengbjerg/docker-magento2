# ReviewGraphQl

**ReviewGraphQl** provides endpoints for getting and creating the Product reviews by guest and logged in customers.
