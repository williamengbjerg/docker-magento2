# CustomerGraphQl

**CustomerGraphQl** provides type and resolver information for the GraphQl module
to generate customer information endpoints.
