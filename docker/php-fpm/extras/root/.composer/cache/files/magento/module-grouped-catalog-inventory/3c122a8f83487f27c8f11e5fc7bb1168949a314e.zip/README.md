Magento_GroupedCatalogInventory contains behavior related to the inventory status of items within grouped products.
