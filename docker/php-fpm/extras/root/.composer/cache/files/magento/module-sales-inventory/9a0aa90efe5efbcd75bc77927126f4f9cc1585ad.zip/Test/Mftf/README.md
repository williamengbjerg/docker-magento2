# Sales Inventory Functional Tests

The Functional Test Module for **Magento Sales Inventory** module.
