# Version Functional Tests

The Functional Test Module for **Magento Version** module.
