Please refer to: https://github.com/magento/security-package
