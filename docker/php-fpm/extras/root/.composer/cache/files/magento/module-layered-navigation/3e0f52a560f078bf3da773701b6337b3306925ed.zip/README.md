Magento_LayeredNavigation module introduces Layered Navigation UI for Catalog (faceted search).
This module can be removed from Magento installation without impact on the application.
