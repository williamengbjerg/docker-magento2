The Magento_NewsletterGraphQl module allows a shopper to subscribe to a newsletter using GraphQL.
