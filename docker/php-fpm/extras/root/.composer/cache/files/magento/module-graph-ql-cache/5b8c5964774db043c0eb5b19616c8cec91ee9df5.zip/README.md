# GraphQl Cache

**GraphQL Cache** provides the ability to cache GraphQL queries.
This module allows Magento's built-in cache or Varnish as the application for serving the Full Page Cache to the front end. 
