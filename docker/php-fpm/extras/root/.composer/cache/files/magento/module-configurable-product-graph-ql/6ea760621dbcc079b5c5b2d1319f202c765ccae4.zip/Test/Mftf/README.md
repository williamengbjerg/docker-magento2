# Configurable Product Graph Ql Functional Tests

The Functional Test Module for **Magento Configurable Product Graph Ql** module.
