# Catalog Rule Functional Tests

The Functional Test Module for **Magento Catalog Rule** module.
