# Magento_LoginAsCustomerAssistance module

The Magento_LoginAsCustomerAssistance module provides possibility to enable/disable LoginAsCustomer functionality per Customer.
