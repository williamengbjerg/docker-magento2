# Magento_MediaGallerySynchronizationMetadata

The purpose of this module is to include assets metadata to media gallery synchronization process
