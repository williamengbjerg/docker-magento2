# Functional Tests

The Functional Tests for **Magento Login as Customer** module.
