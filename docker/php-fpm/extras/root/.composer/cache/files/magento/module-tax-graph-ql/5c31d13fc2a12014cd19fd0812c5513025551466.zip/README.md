# TaxGraphQl

**TaxGraphQl** provides type information for the GraphQl module
to generate tax fields for catalog and product information endpoints.
