# ThemeGraphQl

**ThemeGraphQl** provides type information for the GraphQl module
to generate theme fields information endpoints.
