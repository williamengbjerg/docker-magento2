==================================
Rule set ``@PHP71Migration:risky``
==================================

Rules to improve code for PHP 7.1 compatibility. This set contains rules that are risky.

Rules
-----

- `@PHP70Migration:risky <./PHP70MigrationRisky.rst>`_
- `void_return <./../rules/function_notation/void_return.rst>`_
