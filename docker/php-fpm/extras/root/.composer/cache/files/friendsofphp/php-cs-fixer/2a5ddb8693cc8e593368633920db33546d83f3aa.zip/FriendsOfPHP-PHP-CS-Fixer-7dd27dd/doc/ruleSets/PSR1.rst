==================
Rule set ``@PSR1``
==================

Rules that follow `PSR-1 <https://www.php-fig.org/psr/psr-1/>`_ standard.

Rules
-----

- `encoding <./../rules/basic/encoding.rst>`_
- `full_opening_tag <./../rules/php_tag/full_opening_tag.rst>`_
