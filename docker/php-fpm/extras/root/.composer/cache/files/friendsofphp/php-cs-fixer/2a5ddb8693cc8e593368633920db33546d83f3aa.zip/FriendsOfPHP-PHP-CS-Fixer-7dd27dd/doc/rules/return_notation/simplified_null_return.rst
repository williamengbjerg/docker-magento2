===============================
Rule ``simplified_null_return``
===============================

A return statement wishing to return ``void`` should not return ``null``.

Examples
--------

Example #1
~~~~~~~~~~

.. code-block:: diff

   --- Original
   +++ New
   @@ -1 +1 @@
   -<?php return null;
   +<?php return;

Example #2
~~~~~~~~~~

.. code-block:: diff

   --- Original
   +++ New
   @@ -1,5 +1,5 @@
    <?php
   -function foo() { return null; }
   +function foo() { return; }
    function bar(): int { return null; }
    function baz(): ?int { return null; }
   -function xyz(): void { return null; }
   +function xyz(): void { return; }
