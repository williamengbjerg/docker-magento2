============================
Rule set ``@PHP70Migration``
============================

Rules to improve code for PHP 7.0 compatibility.

Rules
-----

- `@PHP56Migration <./PHP56Migration.rst>`_
- `ternary_to_null_coalescing <./../rules/operator/ternary_to_null_coalescing.rst>`_
