<?php

declare(strict_types=1);

namespace GraphQL\Type\Definition;

/*
export type GraphQLNamedType =
  | GraphQLScalarType
  | GraphQLObjectType
  | GraphQLInterfaceType
  | GraphQLUnionType
  | GraphQLEnumType
  | GraphQLInputObjectType;
 */

interface NamedType
{
}
