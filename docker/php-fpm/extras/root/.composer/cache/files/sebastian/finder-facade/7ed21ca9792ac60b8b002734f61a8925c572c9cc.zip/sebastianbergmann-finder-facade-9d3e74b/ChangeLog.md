# ChangeLog

All notable changes are documented in this file using the [Keep a CHANGELOG](http://keepachangelog.com/) principles.

## [2.0.0] - 2020-02-08

### Changed

* Files are now sorted by name

### Removed

* Removed support for PHP versions older than PHP 7.3

[2.0.0]: https://github.com/sebastianbergmann/diff/compare/1.2.2...2.0.0
