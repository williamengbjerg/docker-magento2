# laminas-loader

[![Build Status](https://github.com/laminas/laminas-loader/workflows/Continuous%20Integration/badge.svg)](https://github.com/laminas/laminas-loader/actions?query=workflow%3A"Continuous+Integration")

laminas-loader provides different strategies for autoloading PHP classes.

- File issues at https://github.com/laminas/laminas-loader/issues
- Documentation is at https://docs.laminas.dev/laminas-loader/
