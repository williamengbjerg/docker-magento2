Copyright (c) 2019, Laminas Foundation.
All rights reserved. (https://getlaminas.org/)
