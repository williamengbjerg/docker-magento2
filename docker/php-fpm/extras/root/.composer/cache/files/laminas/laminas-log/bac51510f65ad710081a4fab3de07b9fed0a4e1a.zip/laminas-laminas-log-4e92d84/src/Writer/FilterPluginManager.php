<?php

/**
 * @see       https://github.com/laminas/laminas-log for the canonical source repository
 * @copyright https://github.com/laminas/laminas-log/blob/master/COPYRIGHT.md
 * @license   https://github.com/laminas/laminas-log/blob/master/LICENSE.md New BSD License
 */

namespace Laminas\Log\Writer;

/**
 * @deprecated has simply be moved to the parent directory
 */
class FilterPluginManager extends \Laminas\Log\FilterPluginManager
{
}
