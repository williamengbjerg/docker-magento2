# laminas-psr7bridge

[![Build Status](https://travis-ci.org/laminas/laminas-psr7bridge.svg?branch=master)](https://travis-ci.org/laminas/laminas-psr7bridge)

Code for converting [PSR-7](http://www.php-fig.org/psr/psr-7/) messages to
[laminas-http](https://github.com/laminas/laminas-http) messages, and vice
versa.

**Note: This project is a work in progress.**

- Issues: https://github.com/laminas/laminas-psr7bridge/issues
- Documentation: https://docs.laminas.dev/laminas-psr7bridge/
