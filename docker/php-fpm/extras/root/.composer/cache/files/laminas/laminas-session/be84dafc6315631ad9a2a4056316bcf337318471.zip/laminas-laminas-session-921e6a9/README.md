# laminas-session

[![Build Status](https://travis-ci.com/laminas/laminas-session.svg?branch=master)](https://travis-ci.com/laminas/laminas-session)
[![Coverage Status](https://coveralls.io/repos/github/laminas/laminas-session/badge.svg?branch=master)](https://coveralls.io/github/laminas/laminas-session?branch=master)

laminas-session manages PHP sessions using an object oriented interface. 

- File issues at https://github.com/laminas/laminas-session/issues
- Documentation is at https://docs.laminas.dev/laminas-session/
