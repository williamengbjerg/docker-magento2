# laminas-serializer

[![Build Status](https://travis-ci.org/laminas/laminas-serializer.svg?branch=master)](https://travis-ci.org/laminas/laminas-serializer)
[![Coverage Status](https://coveralls.io/repos/github/laminas/laminas-serializer/badge.svg?branch=master)](https://coveralls.io/github/laminas/laminas-serializer?branch=master)

laminas-serializer provides an adapter-based interface for generating and
recovering from storable representations of PHP types.

- File issues at https://github.com/laminas/laminas-serializer/issues
- Documentation is at https://docs.laminas.dev/laminas-serializer/
