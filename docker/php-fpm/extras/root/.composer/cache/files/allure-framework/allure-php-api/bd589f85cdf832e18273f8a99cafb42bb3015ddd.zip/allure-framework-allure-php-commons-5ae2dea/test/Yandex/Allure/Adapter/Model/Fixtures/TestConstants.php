<?php

namespace Yandex\Allure\Adapter\Model\Fixtures;

class TestConstants
{
    const TEST_CONSTANT = 'test-value';
}
