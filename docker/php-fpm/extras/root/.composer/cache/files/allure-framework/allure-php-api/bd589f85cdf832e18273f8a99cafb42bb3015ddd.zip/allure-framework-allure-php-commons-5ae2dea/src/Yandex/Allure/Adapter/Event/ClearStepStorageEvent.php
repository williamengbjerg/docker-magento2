<?php

namespace Yandex\Allure\Adapter\Event;

use Yandex\Allure\Adapter\Model\Entity;

class ClearStepStorageEvent implements StepEvent
{
    public function process(Entity $context)
    {
    }
}
