PHP Collection
==============

Learn more about it in its [documentation](http://jmsyst.com/libs/php-collection).
