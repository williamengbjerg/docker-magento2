<?php

namespace League\ISO3166\Exception;

interface ISO3166Exception extends \Throwable
{
}
