<?php
namespace PhpAmqpLib\Exception;

class AMQPSocketException extends AMQPRuntimeException
{
}
