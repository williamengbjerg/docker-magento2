# PHP-CS-Fixer/diff

This version is for PHP CS Fixer only! Do not use it!

Code from `sebastian/diff` has been forked a republished by permission of Sebastian Bergmann.
Licenced with BSD-3-Clause @ see LICENSE_DIFF, copyright (c) Sebastian Bergmann <sebastian@phpunit.de>
https://github.com/sebastianbergmann/diff

Code from `GeckoPackages/GeckoDiffOutputBuilder` has been copied and republished by permission of GeckoPackages.
Licenced with MIT @ see LICENSE_GECKO, copyright (c) GeckoPackages https://github.com/GeckoPackages
https://github.com/GeckoPackages/GeckoDiffOutputBuilder/

For questions visit us @ https://gitter.im/PHP-CS-Fixer/Lobby
