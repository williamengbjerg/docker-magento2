# ChangeLog

Changelog for v1.0

First stable release, based on:
https://github.com/sebastianbergmann/diff/releases
1.4.3 and 2.0.1
